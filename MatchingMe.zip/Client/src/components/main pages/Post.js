import React from 'react';

export default class Post extends React.Component {
    render(){
        return(
            <h1>
                <b>Create a Post</b>
            </h1>
        )
    }
} 