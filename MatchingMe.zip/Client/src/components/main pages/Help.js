import React from 'react';

export default class Help extends React.Component {
    render(){
        return(
            <h1>
                <b>Help Page</b>
            </h1>
        )
    }
} 