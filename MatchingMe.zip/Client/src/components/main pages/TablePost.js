import React from 'react';
import ListPost from './sectionsHome/ListPostsPage';

export default class TablePost extends React.Component {
    render(){
        return(
            <ListPost />
        )
    }
} 