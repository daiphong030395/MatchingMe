import React from 'react';

export default class Main extends React.Component{
    render(){
        return(
            <div>
                MAIN CONTENTS
            </div>
        )
    }
}