import React from 'react';

export default class NotFoundPage extends React.Component {
    render(){
        return(
            <h1>
                <b>404</b> PAGE NOT FOUND
            </h1>
        )
    }
} 